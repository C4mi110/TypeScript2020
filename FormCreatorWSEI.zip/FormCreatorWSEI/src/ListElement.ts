import {Field} from './interfaceField';
import {Socket} from 'dgram';
import '../src/client';

export class ListElement {
    Table: HTMLElement;
    fields: Field[];
    editButton: HTMLElement;
    deleteButton: HTMLElement;
    keyID: number;
    ValuesForSavingInStorage: any[];

    constructor (fields: Field[], ID: number) {
        this.fields = fields;
        this.keyID = ID;
        this.ValuesForSavingInStorage = new Array();
        this.Table = document.querySelector("#listTable");

        const editbutton = <HTMLButtonElement>document.createElement('button');
        editbutton.innerHTML = "EDIT";
        editbutton.className = "editButton";
        editbutton.addEventListener('click', () => this.editList());
        this.editButton = editbutton;

        
        //this.deleteButton = deletebutton;

        //this.Table.appendChild(this.deleteButton);
        this.Table.appendChild(this.editButton);

        this.setArray();
        this.createElement();
    }

    setArray() {
        this.fields.forEach( el => {
            this.ValuesForSavingInStorage.push(
                {
                    label: el.labelValue, 
                    value: el.getValue()
                }
            );
        });
    }

    createElement() {
        //this.Table.innerHTML="";
        for(var i=0; i < this.ValuesForSavingInStorage.length; i++) {
                const deletebutton = <HTMLButtonElement>document.createElement('button');
                deletebutton.innerHTML = "x" 
                deletebutton.className = "deleteButton";    
                deletebutton.addEventListener('click', () => this.deleteFieldValue(i, this.ValuesForSavingInStorage[i].label));

                const tr = document.createElement('tr');
                const tl = document.createElement('th');
                const td = document.createElement('td');
                tl.innerHTML = this.ValuesForSavingInStorage[i].label;
                td.innerHTML = this.ValuesForSavingInStorage[i].value;
                td.appendChild(deletebutton);
                tr.appendChild(tl);
                tr.appendChild(td);
                this.Table.appendChild(tr);
            }
        this.sendValuesToServer();
    }

    deleteFieldValue(index, label) {
        for(var i=0; i < this.ValuesForSavingInStorage.length; i++) 
            if(index === i || this.ValuesForSavingInStorage[i].label === label)
                this.ValuesForSavingInStorage[i].value = "";
        this.createElement();
    }

    editList() {
        let data = this.Table.getElementsByTagName('td');

        for (let i = 0; i < data.length; i++) {
            if (data[i].isContentEditable === false) {
                data[i].setAttribute('contenteditable', 'true');
            } 
            else {
                data[i].setAttribute('contenteditable', 'false');
            }            
        }
    }


    deleteList() {
        const parentNode = document.getElementById('listContainer');
        console.log(parentNode);
        parentNode.removeChild(this.Table);
    }

    sendValuesToServer() : void {
        console.log('Sending to localhost');
        let socket = new WebSocket("ws://localhost:8080");
        this.ValuesForSavingInStorage.forEach(e => {
            socket.onmessage = function() {
                console.log(e.getValue())
            };
        })
    }
}