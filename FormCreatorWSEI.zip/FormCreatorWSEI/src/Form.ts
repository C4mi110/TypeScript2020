import {Field} from './interfaceField';
import {ListElement} from './ListElement';

export class Form {
    fields: Field[];
    formContainer: HTMLElement;
    ValuesContainer: HTMLElement;
    DivForLists: HTMLElement;
    keyID: number = 0;
    AllListElements: any[];

    constructor(idForm: string, idValues: string) {
        this.fields = new Array();
        this.AllListElements = new Array();
        this.formContainer = document.getElementById(idForm);
        this.ValuesContainer = document.getElementById(idValues);
        this.DivForLists = document.querySelector("#listContainer");
        this.ValuesContainer.appendChild(this.DivForLists);
    }

    render(): void {
        this.fields.forEach(element => {
            var div = <HTMLElement>document.createElement("div");
            div.className="input_div";
            div.appendChild(element.Label);
            div.appendChild(element.render())   ;
            this.formContainer.appendChild(div);
        });
    }

    renderValue(): void {    
        const element = new ListElement(this.fields, this.keyID);
        this.DivForLists.appendChild(element.Table);
        this.keyID++;
        this.AllListElements.push(element.ValuesForSavingInStorage);
        console.log(this.AllListElements);
    }

}