import {Field} from './interfaceField';
import {TextBox} from './TextBox';
import {TextArea} from './TextArea';
import {DateField} from './DateField';
import {EmailField} from './EmailField';
import {CheckboxField} from './Checkbox';
import {SelectField} from './SelectField';
import {ListElement} from './ListElement';
import {Form} from './Form';

import './styles/styles.scss';


class App {
    form: Form;
    submitbutton: HTMLElement;
    loadStorageButton: HTMLElement;
    saveToStorageButton: HTMLElement;

    constructor(...elements: Field[]) {
        this.form = new Form('formContainer', 'formValueContainer');
        this.form.fields.push(...elements);

        this.submitbutton = document.getElementById('Submit');
        this.submitbutton.addEventListener('click', () => {
            this.renderValue();
            //this.saveListToStorage();
         });

        this.loadStorageButton = document.getElementById('loadStorage');
        this.loadStorageButton.addEventListener('click', () => this.loadListFromStorage());

        this.saveToStorageButton = document.getElementById('saveToStorage');
        this.saveToStorageButton.addEventListener('click', () => this.saveListToStorage());
    }

    appStart() {
        this.form.render();
    }

    renderValue() {
        this.form.renderValue();
        
        this.form.fields.forEach(element => {
            element.setValue("");
        });
    }

    saveListToStorage() {
        localStorage.setItem("elements", JSON.stringify(this.form.AllListElements));
        console.log('done');
    }

    loadListFromStorage() {
        /*this.form.DivForLists.innerHTML="";
        const arr: Array<Array<string>> = JSON.parse(localStorage.getItem('elements'));
        console.log(arr);
        arr.forEach(element => {
            const lista = <HTMLTableElement>document.createElement('table');
            lista.className = "lista";
            element.forEach(tableRow => {
                console.log(tableRow);
                const tr = document.createElement('tr');
                const tl = document.createElement('th');
                const td = document.createElement('td');
                tl.innerHTML = tableRow['label'].toString();
                td.innerHTML = tableRow['value'].toString();
                tr.appendChild(tl);
                tr.appendChild(td);
                lista.appendChild(tr);
            });
            this.form.DivForLists.appendChild(lista);
        });*/   
    }

}

const textbox = new TextBox('Name', 'Name');
const textbox2 = new TextBox('SurName', 'SurName');
const email = new EmailField('Email', 'Email');
const select = new SelectField('HomeCountry', 'Home Country');
const checkbox = new CheckboxField('eLearning', 'Do you like e learning?');
const datetime = new DateField('Date', 'Date');
const textarea = new TextArea('Comments', 'Comments');

window.onload = function() {
    const app = new App(textbox, textbox2, email, select, checkbox, datetime, textarea);
    app.appStart();
    app.loadListFromStorage();
}
